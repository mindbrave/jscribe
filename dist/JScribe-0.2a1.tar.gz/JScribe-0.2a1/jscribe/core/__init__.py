# -*- coding: utf-8 -*-
#!/usr/bin/env python

"""* Core modules.
@package jscribe.core
"""