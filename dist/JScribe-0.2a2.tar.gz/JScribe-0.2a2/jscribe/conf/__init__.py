# -*- coding: utf-8 -*-
#!/usr/bin/env python

"""* Package with configuration related modules.
@package jscribe.conf
"""