TEMPLATE_SETTINGS = {
    "SHOW_LINE_NUMBER": True,
    "FOOTER_TEXT": "JSCRIBE",
    "LOGO_PATH": "",
    "ELEMENT_TEMPLATES": {
        "default": "default_element.html"
    }
}
# python path to generator class (module path, class)
GENERATOR = ('jscribe.generators.html.htmldefaultgenerator', 'HTMLDefaultGenerator')