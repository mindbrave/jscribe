# -*- coding: utf-8 -*-
#!/usr/bin/env python

"""* Utility modules package.
@package jscribe.utils
"""