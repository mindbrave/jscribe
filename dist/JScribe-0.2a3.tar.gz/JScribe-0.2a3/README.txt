===============================
JScribe documentation generator
===============================

JScribe generates documentation from code source files for you.

It can be used with any langauge, but was designed for Javascript mainly.

Check http://mindbrave.com/jscribe/docs/